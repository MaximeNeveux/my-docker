Snake Basket
===========

A sample project to experiment Python packaging.
